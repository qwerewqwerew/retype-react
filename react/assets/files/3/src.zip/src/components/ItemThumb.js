import './ItemThumb.css';
const ItemThumb = (props) => {
	console.log("props",props);
	return (
		<div className="list_img">
			<img src={props.thumb} alt={''} />
		</div>
	);
};
export default ItemThumb;
