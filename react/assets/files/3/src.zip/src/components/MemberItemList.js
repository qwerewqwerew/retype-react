import ItemThumb from './ItemThumb';
import ItemDesc from './ItemDesc';
const MemberItemList = (props) => {
	return (
		<li className="list_item">
			<ItemThumb thumb={props.thumb} ></ItemThumb>
			<ItemDesc name={props.name} email={props.email}></ItemDesc>
		</li>
	);
};









export default MemberItemList;
