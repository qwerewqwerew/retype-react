//Member.js
const Member = () => {
	return (
		<>
			<span>이름:</span>
			<span>김망고</span>
		</>
	);
};
export default Member;
