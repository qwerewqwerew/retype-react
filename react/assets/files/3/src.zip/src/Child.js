//Child.js
import "./Child.css";
function Child (){
 return <h3 className='red'>나는 자식 입니다.</h3>
}
export default Child;