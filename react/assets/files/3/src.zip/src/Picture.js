//Picture.js
const Picture = () => {
	return (
		<>
			<span>사진:</span>
			<img src="http://qwerew.cafe24.com/images/pet-5.jpg" alt="" />
		</>
	);
};

export { Picture };
