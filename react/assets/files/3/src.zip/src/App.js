import logo from "./logo.svg";
import MemberItem from './components/MemberItem';

const App = () => {
	const memberDB = [
		{ id: 'm1', name: '김경아', thumb: 'http://qwerew.cafe24.com/images/pet-1.jpg', email: 'abc@def.com' },
		{ id: 'm2', name: '김망고', thumb: 'http://qwerew.cafe24.com/images/pet-2.jpg', email: 'dge@def.com' },
		{ id: 'm3', name: '김민정', thumb: 'http://qwerew.cafe24.com/images/pet-3.jpg', email: 'weet@def.com' },
		{ id: 'm4', name: '윤현선', thumb: 'http://qwerew.cafe24.com/images/pet-4.jpg', email: 'gss@def.com' },
		{ id: 'm5', name: '이소정', thumb: 'http://qwerew.cafe24.com/images/pet-5.jpg', email: 'xxt@def.com' },
	];
	return (
		<div>
			<img src={logo} alt="logo" style={{width:'100px'}} />
			<MemberItem db={memberDB}/>
		</div>
	);
};
export default App;
